# -*- coding: utf-8 -*-
# @Author : zw
import time
import unittest
from BeautifulReport import BeautifulReport

suite = unittest.defaultTestLoader.discover("./", pattern="test*.py")

result = BeautifulReport(suite)
result.report(description="积坔云系统接口测试报告", filename=time.strftime("%Y_%m_%d_%H_%M_%S") + "_测试报告",
              report_dir=r"../report/")
