import ddt
import requests
import scripts as si
import unittest
from tool.get_log import GatLog
from tool.get_sql_data import GetSqlData

# 实例化日志对象
log = GatLog.get_log()


@ddt.ddt
class TestUserAccountService(unittest.TestCase):
    # 拼接接口地址
    loginV1_url = si.base_url + si.loginV1
    getUserInfoByUserIdV1_url = si.base_url + si.getUserInfoByUserIdV1
    getCertificationInfoByUserIdV1 = si.base_url + si.getCertificationInfoByUserIdV1
    getBankCardV1 = si.base_url + si.getBankCardV1
    loginNotWithPassWord = si.base_url + si.loginNotWithPassWord

    # 参数化
    @ddt.data(*GetSqlData("loginV1").getSqlData())
    @ddt.unpack
    def test_1_LoginV1(self, LoginName, Password, IMEI, ReturnMsg, ReturnCode):
        """
        登录接口
        :param LoginName:
        :param Password:
        :param IMEI:
        :param ReturnMsg:
        :param ReturnCode:
        """
        log.info("登录接口地址:{}".format(TestUserAccountService.loginV1_url))
        # 请求参数
        data = {
            "LoginName": LoginName,
            "Password": Password,
            "IMEI": IMEI
        }
        log.info("登录请求参数:{}".format(data))
        # 发送请求
        r = requests.post(TestUserAccountService.loginV1_url, json=data)
        print(r)
        result = r.json()
        print(result)
        log.info("登录接口返回:{}".format(result))
        # 断言-判断接口返回ReturnCode和ReturnMsg
        assert result["ReturnMsg"] == ReturnMsg
        assert result["ReturnCode"] == ReturnCode
        # 获取token
        if result["ReturnCode"] == 1:
            self.token = result["ReturnData"]["ToKen"]
            print(self.token)
            return self.token

    @ddt.unpack
    # 参数化
    @ddt.data(*GetSqlData("GetUserInfoByUserIdV1").getSqlData())
    def test_2_GetUserInfoByUserIdV1(self, userType, userId, token, ReturnMsg, ReturnCode):
        """
        查询用户信息
        :param userType:
        :param userId:
        :param token:
        :param ReturnMsg:
        :param ReturnCode:
        """
        # 查询用户信息接口地址
        self.url = TestUserAccountService.getUserInfoByUserIdV1_url + "?userType=" + str(userType) + "&userId=" + str(
            userId) + "&token=" + token
        log.info("获取用户信息接口请求地址:{}".format(self.url))
        r = requests.get(url=self.url)
        print(r)
        result = r.json()
        print(result)
        log.info("获取用户信息接口返回:{}".format(result))
        assert result["ReturnMsg"] == ReturnMsg
        assert result["ReturnCode"] == ReturnCode

    @ddt.unpack
    @ddt.data(*GetSqlData("GetCertificationInfoByUserIdV1").getSqlData())
    def test_3_GetCertificationInfoByUserIdV1(self, userId, token, ReturnMsg, ReturnCode):
        """
        获取用户认证信息
        :param userId:
        :param token:
        :param ReturnMsg:
        :param ReturnCode:
        """
        self.url = TestUserAccountService.getCertificationInfoByUserIdV1 + "?userType=" + "&userId=" + str(
            userId) + "&token=" + token
        log.info("获取用户认证信息接口请求地址:{}".format(self.url))
        r = requests.get(url=self.url)
        result = r.json()
        print(result)
        log.info("获取用户认证信息接口返回:{}".format(result))
        assert result["ReturnMsg"] == ReturnMsg
        assert result["ReturnCode"] == ReturnCode

    @ddt.unpack
    @ddt.data(*GetSqlData("GetBankCardV1").getSqlData())
    def test_4_GetBankCardV1(self, userId, token, ReturnMsg, ReturnCode):
        """
        获取绑卡信息
        :param userId:
        :param token:
        :param ReturnMsg:
        :param ReturnCode:
        """
        self.url = TestUserAccountService.getBankCardV1 + "?userId=" + str(
            userId) + "&token=" + token
        log.info("获取绑卡信息接口请求地址:{}".format(self.url))
        r = requests.get(url=self.url)
        result = r.json()
        print(result)
        log.info("获取绑卡信息接口返回:{}".format(result))
        assert result["ReturnMsg"] == ReturnMsg
        assert result["ReturnCode"] == ReturnCode

    @ddt.unpack
    @ddt.data(("18355708165", 0, "9ee6d8d18654403c9f77fd5c638e3123", "登录成功", 1),
              ("18602181111", 0, "9ee6d8d18654403c9f77fd5c638e3123", "用户未注册或已注册未认证", -1))
    def test_5_LoginNotWithPassWord(self, LoginName, StuffId, Token, ReturnMsg, ReturnCode):
        """
        用户免密登录
        :param LoginName:
        :param StuffId:
        :param Token:
        :param ReturnMsg:
        :param ReturnCode:
        """
        self.url = TestUserAccountService.loginNotWithPassWord
        parm = {
            "LoginName": LoginName,
            "StuffId": StuffId,
            "Token": Token
        }
        r = requests.post(url=self.url, json=parm)
        result = r.json()
        print(result)
        assert result["ReturnMsg"] == ReturnMsg
        assert result["ReturnCode"] == ReturnCode
