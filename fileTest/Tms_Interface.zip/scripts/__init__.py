# 接口请求地址
base_url = r'http://tst.api.liinji.local'
# 登录接口
loginV1 = r"/api/UserAccountService/LoginV1"
# 查询用户信息接口
getUserInfoByUserIdV1 = r"/api/UserAccountService/GetUserInfoByUserIdV1"
# 查询认证信息
getCertificationInfoByUserIdV1 = r"/api/UserAccountService/GetCertificationInfoByUserIdV1"
# 查询绑卡信息
getBankCardV1 = r"/api/UserAccountService/GetBankCardV1"
# 免密码登录
loginNotWithPassWord = r"/api/UserAccountService/LoginNotWithPassWord"
