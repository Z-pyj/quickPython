import pymssql


class GetSqlData:
    def __init__(self, tableName):
        self.tableName = tableName
        # 初始化连接数据库
        self.server = r'10.111.12.51'  # 服务器ip或名称
        self.user = r'test_zw_rw'  # 用户名
        self.password = r'Lj@Zw@123./*'  # 密码
        self.database = r'TMS_Web'  # 数据库
        self.conn = pymssql.connect(server=self.server, user=self.user, password=self.password,
                                    database=self.database, charset='cp936')  # 连接到数据库

    def getSqlData(self):
        cur = self.conn.cursor()  # 创建一个游标对象,python里的sql语句都要通过cursor来执行
        sql = "select * from "+str(self.tableName)+";"
        print(sql)
        cur.execute(sql)  # 执行sql语句
        rows = cur.fetchall()  # 读取查询结果,
        cur.close()
        self.conn.close()
        return rows


if __name__ == "__main__":
    pe = GetSqlData("GetUserInfoByUserIdV1")
    data = pe.getSqlData()
    print(data)
