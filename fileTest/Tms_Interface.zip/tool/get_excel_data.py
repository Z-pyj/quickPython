# -*- coding: utf-8 -*-
# @Author : zw
from openpyxl import load_workbook


class GetData:
    def __init__(self, excelPath, sheetName):
        # 将要读取的excel加载到内存
        self.wb = load_workbook(excelPath)
        # 根据工作表名获取一个工作表对象
        self.sheet = self.wb.get_sheet_by_name(sheetName)
        # 获取工作表中存在数据的区域最大行号
        self.maxRowNum = self.sheet.max_row

    def get_data_from_sheet(self):
        # 用于存储工作表中读取出来的数据
        datalist = []
        # 因为工作表中第一行为标题行，所以去掉
        for line in self.sheet.rows[1:]:
            tmplist = []
            tmplist.append(line[1].value)
            tmplist.append(line[2].value)
            tmplist.append(line[3].value)
            tmplist.append(line[4].value)
            datalist.append(tmplist)
        return datalist


if __name__ == "__main__":
    excelPath = u"../data/测试数据.xlsx"
    sheetName = u"login"
    pe = GetData(excelPath, sheetName)
    print(pe.get_data_from_sheet())
    for i in pe.get_data_from_sheet():
        print(i[0], i[1], i[2], i[3])
